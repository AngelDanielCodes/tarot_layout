# Documentación Completa TarotiA v2.0

## Índice Detallado

[Contenido previo del índice...]

## Sistema de Cartas

### Estructura de Datos

La estructura de datos de las cartas está diseñada para máxima flexibilidad y reutilización:

```typescript
interface CardData {
  id: number;
  name: string;
  type: 'majorArcana' | 'minorArcana';
  suit?: 'wands' | 'cups' | 'swords' | 'pentacles';
  number: number;
  image: string;
  descriptions: {
    [key: string]: SpreadDescription;
  };
}

interface SpreadDescription {
  description: string;
  positiveReading: string;
  negativeReading: string;
  image?: string;
}
```

#### Organización de Archivos
```plaintext
src/data/
├── cards/
│   ├── majorArcana.ts    # 22 cartas mayores
│   ├── wands.ts          # 14 cartas de bastos
│   ├── cups.ts           # 14 cartas de copas
│   ├── swords.ts         # 14 cartas de espadas
│   └── pentacles.ts      # 14 cartas de oros
└── spreads/
    ├── celtic.ts         # Configuración Cruz Celta
    ├── star.ts           # Configuración Estrella
    └── love.ts           # Configuración Amor
```

### Sistema de Imágenes

#### Gestión de Imágenes
```typescript
// Ejemplo de configuración de imágenes para diferentes modos
export const cardBacks = {
  'tirada-celta': {
    image: '/images/backs/celtic-back.jpg',
    alt: 'Reverso Cruz Celta',
    preload: true
  },
  'tirada-estrella': {
    image: '/images/backs/star-back.jpg',
    alt: 'Reverso Estrella',
    preload: true
  }
  // ... más configuraciones
};

// Utilidad para precarga de imágenes
export const preloadImages = () => {
  Object.values(cardBacks).forEach(back => {
    if (back.preload) {
      const img = new Image();
      img.src = back.image;
    }
  });
};
```

### Lógica de Selección de Cartas

```typescript
// Hook personalizado para selección de cartas
const useCardSelection = (spreadType: string, totalCards: number) => {
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [usedCards, setUsedCards] = useState<number[]>([]);

  const selectCard = useCallback((position: number) => {
    // Verificar si la posición es válida
    if (position !== selectedCards.length + 1) return;

    // Obtener cartas disponibles
    const availableCards = getAvailableCards(usedCards);
    if (availableCards.length === 0) return;

    // Seleccionar carta aleatoria
    const randomCard = availableCards[
      Math.floor(Math.random() * availableCards.length)
    ];

    // Actualizar estados
    setSelectedCards(prev => [...prev, position]);
    setUsedCards(prev => [...prev, randomCard.id]);

    return randomCard;
  }, [selectedCards, usedCards]);

  return {
    selectedCards,
    usedCards,
    selectCard,
    isComplete: selectedCards.length === totalCards
  };
};
```

## Sistema de Animaciones

### Configuración de Framer Motion

```typescript
// Variantes de animación para cartas
export const cardVariants = {
  initial: { 
    scale: 0.8, 
    opacity: 0,
    y: 20 
  },
  animate: { 
    scale: 1, 
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 300,
      damping: 20
    }
  },
  exit: { 
    scale: 0.8, 
    opacity: 0,
    transition: { 
      duration: 0.2 
    }
  },
  hover: {
    scale: 1.05,
    transition: {
      type: "spring",
      stiffness: 400,
      damping: 10
    }
  }
};

// Componente de carta animada
const AnimatedCard: React.FC<AnimatedCardProps> = ({ card, onClick }) => {
  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      whileHover="hover"
      layoutId={`card-${card.id}`}
      onClick={onClick}
    >
      {/* Contenido de la carta */}
    </motion.div>
  );
};
```

### Optimización de Rendimiento

```typescript
// Componente optimizado para lista de cartas
const OptimizedCardList: React.FC<CardListProps> = ({ cards }) => {
  return (
    <Virtuoso
      style={{ height: '100vh' }}
      totalCount={cards.length}
      itemContent={index => (
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ 
            opacity: 1,
            transition: { delay: index * 0.1 }
          }}
          viewport={{ once: true }}
        >
          <Card data={cards[index]} />
        </motion.div>
      )}
    />
  );
};
```

## Sistema de Sonido

### Configuración de Howler.js

```typescript
// Configuración de sonidos
const sounds = {
  cardFlip: new Howl({
    src: ['/sounds/card-flip.wav'],
    volume: 0.5,
    preload: true,
    pool: 4
  }),
  cardSelect: new Howl({
    src: ['/sounds/card-select.wav'],
    volume: 0.3,
    preload: true,
    pool: 4
  })
};

// Hook personalizado para sonidos
const useTarotSounds = () => {
  const playSound = useCallback(async (soundName: keyof typeof sounds) => {
    try {
      const sound = sounds[soundName];
      if (sound.state() === 'loaded') {
        sound.play();
      } else {
        await new Promise(resolve => sound.once('load', resolve));
        sound.play();
      }
    } catch (error) {
      console.error(`Error playing ${soundName}:`, error);
    }
  }, []);

  return { playSound };
};
```

[Continúa con más secciones detalladas...]

## Sistema de Pago

### Integración con Stripe

```typescript
// Configuración de Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

// Hook para gestión de pagos
const usePayment = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processPayment = async (amount: number) => {
    try {
      setLoading(true);
      const stripe = await stripePromise;
      
      // Crear sesión de pago
      const response = await fetch('/api/create-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount })
      });
      
      const session = await response.json();
      
      // Redirigir a Checkout
      await stripe?.redirectToCheckout({
        sessionId: session.id
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return { processPayment, loading, error };
};
```

[Continúa con el resto de las secciones...]