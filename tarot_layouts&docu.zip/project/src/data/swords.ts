import { CardData } from '../types/cards';

export const swordsSuit: CardData[] = [
  {
    id: 50,
    name: 'As de Espadas',
    type: 'minorArcana',
    suit: 'swords',
    number: 1,
    image: 'https://images.unsplash.com/photo-1601024445121-e294d45c0424',
    descriptions: {
      'tirada-celta': {
        description: 'El As de Espadas en la Cruz Celta representa claridad mental y victoria.',
        positiveReading: 'Un momento de claridad y determinación.',
        negativeReading: 'Pensamientos conflictivos o agresivos.'
      },
      'tirada-estrella': {
        description: 'En la Tirada Estrella, el As de Espadas simboliza la verdad divina.',
        positiveReading: 'Revelación de una verdad importante.',
        negativeReading: 'Resistencia a ver la verdad.'
      },
      'tirada-amor': {
        description: 'En el amor, el As de Espadas indica honestidad y comunicación directa.',
        positiveReading: 'Momento de sinceridad en la relación.',
        negativeReading: 'Palabras hirientes o conflictos.'
      },
      'tirada-tiempo': {
        description: 'Un período de claridad mental y decisiones importantes.',
        positiveReading: 'Momento de tomar decisiones con firmeza.',
        negativeReading: 'Espera a que la mente se aclare.'
      },
      'si-o-no': {
        description: 'El As de Espadas sugiere una respuesta definitiva.',
        positiveReading: 'Sí, con determinación y claridad.',
        negativeReading: 'No, si hay dudas o conflictos.'
      }
    }
  },
  // Continuaré con más cartas de espadas...
  {
    id: 51,
    name: 'Dos de Espadas',
    type: 'minorArcana',
    suit: 'swords',
    number: 2,
    image: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb',
    descriptions: {
      'tirada-celta': {
        description: 'El Dos de Espadas representa un momento de decisión y equilibrio.',
        positiveReading: 'Capacidad de mantener la paz y el equilibrio.',
        negativeReading: 'Indecisión y conflicto interno.'
      },
      // ... (continuaré con las descripciones para cada tipo de tirada)
    }
  }
];