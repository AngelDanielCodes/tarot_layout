import { CardData } from '../types/cards';

export const pentaclesSuit: CardData[] = [
  {
    id: 64,
    name: 'As de Oros',
    type: 'minorArcana',
    suit: 'pentacles',
    number: 1,
    image: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc',
    descriptions: {
      'tirada-celta': {
        description: 'El As de Oros en la Cruz Celta representa nuevas oportunidades materiales.',
        positiveReading: 'Prosperidad y abundancia material.',
        negativeReading: 'Oportunidades perdidas o codicia.'
      },
      'tirada-estrella': {
        description: 'En la Tirada Estrella, simboliza manifestación y recursos divinos.',
        positiveReading: 'Manifestación de abundancia espiritual.',
        negativeReading: 'Apego excesivo a lo material.'
      },
      'tirada-amor': {
        description: 'En el amor, indica estabilidad y seguridad material.',
        positiveReading: 'Base sólida para la relación.',
        negativeReading: 'Materialismo en el amor.'
      },
      'tirada-tiempo': {
        description: 'Un período de oportunidades materiales.',
        positiveReading: 'Momento de inversión y crecimiento.',
        negativeReading: 'Precaución con recursos.'
      },
      'si-o-no': {
        description: 'El As de Oros sugiere una oportunidad tangible.',
        positiveReading: 'Sí, con beneficios materiales.',
        negativeReading: 'No, si solo buscas ganancias.'
      }
    }
  },
  {
    id: 65,
    name: 'Dos de Oros',
    type: 'minorArcana',
    suit: 'pentacles',
    number: 2,
    image: 'https://images.unsplash.com/photo-1534447677768-be436bb09401',
    descriptions: {
      'tirada-celta': {
        description: 'El Dos de Oros en la Cruz Celta representa equilibrio y adaptabilidad.',
        positiveReading: 'Capacidad de manejar múltiples responsabilidades.',
        negativeReading: 'Desorganización o inestabilidad.'
      },
      'tirada-estrella': {
        description: 'En la Tirada Estrella, simboliza el equilibrio entre lo material y espiritual.',
        positiveReading: 'Armonía entre diferentes aspectos de la vida.',
        negativeReading: 'Desequilibrio en prioridades.'
      },
      'tirada-amor': {
        description: 'En el amor, indica la necesidad de equilibrar relación y obligaciones.',
        positiveReading: 'Balance entre amor y responsabilidades.',
        negativeReading: 'Dificultad para mantener el equilibrio.'
      },
      'tirada-tiempo': {
        description: 'Un período de malabarismo y adaptación.',
        positiveReading: 'Flexibilidad y adaptabilidad.',
        negativeReading: 'Sobrecarga de responsabilidades.'
      },
      'si-o-no': {
        description: 'El Dos de Oros sugiere considerar múltiples factores.',
        positiveReading: 'Sí, si mantienes el equilibrio.',
        negativeReading: 'No, si hay demasiada inestabilidad.'
      }
    }
  }
];