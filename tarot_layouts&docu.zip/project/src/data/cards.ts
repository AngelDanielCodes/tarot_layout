import { TarotCard } from '../types/cards';
import { majorArcana } from './majorArcana';
import { wandsSuit } from './wands';
import { cupsSuit } from './cups';
import { swordsSuit } from './swords';
import { pentaclesSuit } from './pentacles';

// Imágenes de reverso específicas para cada modo de tirada
export const cardBacks = {
  'tirada-celta': 'https://images.unsplash.com/photo-1577493340887-b7bfff550145?w=400&q=80&fit=crop',
  'tirada-estrella': 'https://images.unsplash.com/photo-1610991149688-c1321006bcc1?w=400&q=80&fit=crop',
  'tirada-amor': 'https://images.unsplash.com/photo-1596005554384-d293674c91d7?w=400&q=80&fit=crop',
  'tirada-tiempo': 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?w=400&q=80&fit=crop',
  'si-o-no': 'https://images.unsplash.com/photo-1601024445121-e294d45c0424?w=400&q=80&fit=crop'
};

// Combinar todas las cartas
export const allCards = [
  ...majorArcana,
  ...wandsSuit,
  ...cupsSuit,
  ...swordsSuit,
  ...pentaclesSuit
];

// Obtener cartas específicas para un tipo de tirada
export const getCards = (spreadType: string): TarotCard[] => {
  // Asegurarse de que haya suficientes cartas disponibles
  if (allCards.length === 0) {
    console.error('No hay cartas disponibles');
    return [];
  }

  return allCards.map(card => ({
    id: card.id,
    name: card.name,
    type: card.type,
    image: card.descriptions[spreadType]?.image || card.image,
    description: card.descriptions[spreadType]?.description || '',
    positiveReading: card.descriptions[spreadType]?.positiveReading || '',
    negativeReading: card.descriptions[spreadType]?.negativeReading || ''
  }));
};

export const spreadPositions = {
  'tirada-celta': [
    'Situación Actual',
    'Influencia Inmediata',
    'Pasado Distante',
    'Pasado Reciente',
    'Mejor Resultado Posible',
    'Futuro Inmediato',
    'Tu Actitud',
    'Influencias Externas',
    'Esperanzas y Temores',
    'Resultado Final'
  ],
  'tirada-estrella': [
    'Tema Central',
    'Influencias Pasadas',
    'Influencias Ocultas',
    'Poder Personal',
    'Camino Espiritual',
    'Futuro Cercano',
    'Resultado Final'
  ],
  'tirada-amor': [
    'Estado Actual del Amor',
    'Sentimientos de la Pareja',
    'Dinámica de la Relación',
    'Desafíos a Superar',
    'Consejo del Universo',
    'Evolución del Vínculo',
    'Energías Transformadoras',
    'Resultado del Camino'
  ],
  'tirada-tiempo': [
    'Tu Pasado',
    'Tu Presente',
    'Tu Futuro'
  ],
  'si-o-no': [
    'Respuesta a tu Pregunta'
  ]
};

export const getSpreadPositions = (spreadType: string): string[] => {
  return spreadPositions[spreadType as keyof typeof spreadPositions] || [];
};

export const getSpreadDescription = (spreadType: string, position: number): string => {
  const descriptions: Record<string, Record<number, string>> = {
    'tirada-celta': {
      1: 'Esta carta revela la esencia de tu situación actual',
      2: 'Los desafíos inmediatos que enfrentas',
      3: 'Las raíces profundas del asunto',
      4: 'Eventos recientes que han influido',
      5: 'El mejor resultado posible',
      6: 'Los desarrollos que se aproximan',
      7: 'Tu perspectiva personal',
      8: 'Cómo te perciben los demás',
      9: 'Tus deseos y temores más profundos',
      10: 'El resultado final de este camino'
    },
    'tirada-estrella': {
      1: 'El núcleo de tu consulta',
      2: 'Las experiencias que te han formado',
      3: 'Los aspectos ocultos por revelar',
      4: 'Tus recursos internos',
      5: 'Tu conexión espiritual',
      6: 'El futuro cercano',
      7: 'La culminación de tu camino'
    },
    'tirada-amor': {
      1: 'Tu estado emocional actual',
      2: 'Los sentimientos de tu pareja',
      3: 'La dinámica entre ustedes',
      4: 'Los obstáculos a superar',
      5: 'El mensaje del universo',
      6: 'La evolución de la relación',
      7: 'Las energías transformadoras',
      8: 'El destino del amor'
    },
    'tirada-tiempo': {
      1: 'Las influencias de tu pasado',
      2: 'Tu momento presente',
      3: 'El camino hacia tu futuro'
    },
    'si-o-no': {
      1: 'La respuesta a tu pregunta'
    }
  };

  return descriptions[spreadType]?.[position] || 'Interpretación de la carta';
};