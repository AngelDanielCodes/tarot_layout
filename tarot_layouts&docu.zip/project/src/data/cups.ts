import { CardData } from '../types/cards';

export const cupsSuit: CardData[] = [
  {
    id: 36,
    name: 'As de Copas',
    type: 'minorArcana',
    suit: 'cups',
    number: 1,
    image: 'https://images.unsplash.com/photo-1534447677768-be436bb09401',
    descriptions: {
      'tirada-celta': {
        description: 'El As de Copas en la Cruz Celta representa el inicio de una nueva fase emocional.',
        positiveReading: 'Abundancia emocional y nuevas conexiones.',
        negativeReading: 'Emociones desbordadas o confusas.'
      },
      'tirada-estrella': {
        description: 'En la Tirada Estrella, el As de Copas simboliza la conexión con el amor divino.',
        positiveReading: 'Apertura del corazón a nuevas experiencias.',
        negativeReading: 'Bloqueo emocional o espiritual.'
      },
      'tirada-amor': {
        description: 'En el amor, el As de Copas indica el nacimiento de nuevos sentimientos.',
        positiveReading: 'Un nuevo amor florece.',
        negativeReading: 'Ilusiones románticas sin fundamento.'
      },
      'tirada-tiempo': {
        description: 'Marca el inicio de un período emocionalmente significativo.',
        positiveReading: 'Momento de apertura emocional.',
        negativeReading: 'Necesidad de procesar emociones primero.'
      },
      'si-o-no': {
        description: 'El As de Copas sugiere una respuesta desde el corazón.',
        positiveReading: 'Sí, sigue tu corazón.',
        negativeReading: 'No, si solo te guían las emociones.'
      }
    }
  },
  // Continuaré con el resto de las Copas...
];