import { CardData } from '../types/cards';

export const wandsSuit: CardData[] = [
  {
    id: 22,
    name: 'As de Bastos',
    type: 'minorArcana',
    suit: 'wands',
    number: 1,
    image: 'https://images.unsplash.com/photo-1590845947670-c009801ffa74',
    descriptions: {
      'tirada-celta': {
        description: 'El As de Bastos representa una nueva oportunidad creativa.',
        positiveReading: 'Inicio de un proyecto exitoso.',
        negativeReading: 'Energía mal dirigida.'
      },
      'tirada-estrella': {
        description: 'En la Tirada Estrella, simboliza inspiración divina.',
        positiveReading: 'Conexión con la energía creativa.',
        negativeReading: 'Bloqueo de la inspiración.'
      },
      'tirada-amor': {
        description: 'En el amor, indica pasión y entusiasmo.',
        positiveReading: 'Nueva chispa en la relación.',
        negativeReading: 'Pasión sin dirección.'
      },
      'tirada-tiempo': {
        description: 'Momento de iniciar nuevos proyectos.',
        positiveReading: 'Energía favorable para comenzar.',
        negativeReading: 'Esperar el momento adecuado.'
      },
      'si-o-no': {
        description: 'El As de Bastos sugiere acción inmediata.',
        positiveReading: 'Sí, actúa ahora.',
        negativeReading: 'No, si dudas.'
      }
    }
  }
  // ... (continuaré con más cartas)
];