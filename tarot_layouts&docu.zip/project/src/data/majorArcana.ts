import { CardData } from '../types/cards';

export const majorArcana: CardData[] = [
  {
    id: 0,
    name: 'El Loco',
    type: 'majorArcana',
    number: 0,
    image: 'https://images.unsplash.com/photo-1601024445121-e294d45c0424',
    descriptions: {
      'tirada-celta': {
        description: 'El Loco representa el inicio de un viaje espiritual en la Cruz Celta.',
        positiveReading: 'Momento de tomar riesgos y confiar en tu intuición.',
        negativeReading: 'Precaución con decisiones impulsivas.'
      },
      'tirada-estrella': {
        description: 'En la Tirada Estrella, El Loco simboliza libertad espiritual.',
        positiveReading: 'Liberación de limitaciones.',
        negativeReading: 'Caos e inestabilidad.'
      },
      'tirada-amor': {
        description: 'En el amor, El Loco sugiere nuevas aventuras románticas.',
        positiveReading: 'Amor libre y espontáneo.',
        negativeReading: 'Relaciones inestables.'
      },
      'tirada-tiempo': {
        description: 'Un período de cambios inesperados.',
        positiveReading: 'Aventuras y descubrimientos.',
        negativeReading: 'Inestabilidad temporal.'
      },
      'si-o-no': {
        description: 'El Loco sugiere seguir tu instinto.',
        positiveReading: 'Sí, toma el riesgo.',
        negativeReading: 'No, si requiere estabilidad.'
      }
    }
  },
  {
    id: 1,
    name: 'El Mago',
    type: 'majorArcana',
    number: 1,
    image: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb',
    descriptions: {
      'tirada-celta': {
        description: 'El Mago representa el poder de manifestación en la Cruz Celta.',
        positiveReading: 'Dominio de tus habilidades.',
        negativeReading: 'Manipulación o engaño.'
      },
      'tirada-estrella': {
        description: 'En la Tirada Estrella, El Mago simboliza poder divino.',
        positiveReading: 'Canalización de energía espiritual.',
        negativeReading: 'Uso inadecuado del poder.'
      },
      'tirada-amor': {
        description: 'En el amor, El Mago indica habilidad para atraer.',
        positiveReading: 'Magnetismo y carisma.',
        negativeReading: 'Manipulación emocional.'
      },
      'tirada-tiempo': {
        description: 'Momento de tomar acción consciente.',
        positiveReading: 'Período de manifestación.',
        negativeReading: 'Timing inadecuado.'
      },
      'si-o-no': {
        description: 'El Mago sugiere acción consciente.',
        positiveReading: 'Sí, con habilidad.',
        negativeReading: 'No, si hay dudas.'
      }
    }
  }
  // ... (continuaré con las demás cartas mayores)
];