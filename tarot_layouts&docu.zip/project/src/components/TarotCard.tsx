import React, { useEffect, useRef } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import { useSelector } from 'react-redux';
import { RootState } from '../store/store';
import { cardBacks } from '../data/cards';
import 'react-lazy-load-image-component/src/effects/opacity.css';

interface TarotCardProps {
  position: number;
  isRevealed: boolean;
  isSelectable: boolean;
  onClick: () => void;
  spreadType: string;
}

const TarotCard: React.FC<TarotCardProps> = ({
  position,
  isRevealed,
  isSelectable,
  onClick,
  spreadType
}) => {
  const controls = useAnimation();
  const cardRef = useRef<HTMLDivElement>(null);
  const revealedCards = useSelector((state: RootState) => state.tarot.revealedCards);
  const currentCard = revealedCards[position - 1];

  useEffect(() => {
    if (isSelectable) {
      controls.start({
        y: [0, -5, 0],
        transition: {
          duration: 2,
          repeat: Infinity,
          repeatType: "reverse",
          ease: "easeInOut"
        }
      });
    } else {
      controls.stop();
      controls.set({ y: 0 });
    }
  }, [isSelectable, controls]);

  const cardVariants = {
    initial: { scale: 1, y: 0 },
    hover: isSelectable ? { 
      scale: 1.05,
      boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
      transition: { duration: 0.2 }
    } : {},
    tap: isSelectable ? { 
      scale: 0.95,
      transition: { duration: 0.1 }
    } : {}
  };

  const backImage = cardBacks[spreadType] || cardBacks['tirada-celta'];

  return (
    <div className="relative" ref={cardRef}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute -top-8 left-1/2 transform -translate-x-1/2 text-white text-lg font-medium"
      >
        {position}
      </motion.div>
      <motion.div
        variants={cardVariants}
        initial="initial"
        whileHover="hover"
        whileTap="tap"
        animate={controls}
        className={`relative aspect-[2/3] w-32 ${isSelectable ? 'cursor-pointer' : 'cursor-default'}`}
        onClick={() => isSelectable && onClick()}
      >
        <motion.div
          initial={false}
          animate={{ 
            rotateY: isRevealed ? 180 : 0,
            transition: { 
              type: "spring",
              stiffness: 100,
              damping: 15
            }
          }}
          className="w-full h-full [transform-style:preserve-3d]"
        >
          {/* Card Back */}
          <div className={`absolute w-full h-full backface-hidden ${!isRevealed ? 'z-10' : 'z-0'}`}>
            <motion.div 
              className={`w-full h-full rounded-lg border-2 ${
                isSelectable ? 'border-gold shadow-lg shadow-purple-500/50' : 'border-gray-500'
              } overflow-hidden`}
              whileHover={isSelectable ? {
                boxShadow: "0 0 15px rgba(147, 51, 234, 0.5)"
              } : {}}
            >
              <LazyLoadImage
                src={backImage}
                alt="Card Back"
                effect="opacity"
                className="w-full h-full object-cover"
                width={128}
                height={192}
                placeholderSrc={backImage}
              />
            </motion.div>
          </div>

          {/* Card Front */}
          <div className={`absolute w-full h-full backface-hidden [transform:rotateY(180deg)] ${isRevealed ? 'z-10' : 'z-0'}`}>
            <motion.div 
              className="w-full h-full bg-white rounded-lg border-2 border-gold shadow-lg overflow-hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: isRevealed ? 1 : 0 }}
              transition={{ delay: 0.3 }}
            >
              {currentCard && (
                <LazyLoadImage
                  src={currentCard.image}
                  alt={currentCard.name}
                  effect="opacity"
                  className="w-full h-full object-cover"
                  width={128}
                  height={192}
                  placeholderSrc={currentCard.image}
                />
              )}
            </motion.div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default TarotCard;