import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Shield, CreditCard, Lock } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProceed: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onProceed }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-gradient-to-br from-purple-900 to-indigo-900 rounded-2xl p-8 max-w-md w-full mx-4 shadow-xl"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Lectura Completa con IA</h2>
              <button 
                onClick={onClose}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="text-gray-300 mb-6 space-y-2">
              <p>Obtén una interpretación profunda y personalizada de tu tirada de tarot, generada por nuestra IA especializada.</p>
              <div className="flex items-center gap-2 text-purple-300">
                <Shield size={16} />
                <span className="text-sm">Pago 100% seguro</span>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-6 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-white">Precio:</span>
                <span className="text-2xl font-bold text-white">1€</span>
              </div>
              
              <ul className="space-y-3">
                {[
                  'Interpretación detallada de cada carta',
                  'Análisis de las conexiones entre cartas',
                  'Consejos personalizados para tu situación',
                  'Predicciones específicas para cada posición',
                  'Guía para acciones futuras'
                ].map((feature, index) => (
                  <li key={index} className="flex items-center gap-2 text-purple-200">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-4">
              <button
                onClick={onProceed}
                className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 px-6 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
              >
                <CreditCard size={20} />
                Proceder al Pago Seguro
              </button>
              
              <div className="flex items-center justify-center gap-2 text-purple-300 text-sm">
                <Lock size={14} />
                <span>Pago procesado de forma segura</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default PaymentModal;