import React, { useState, useRef } from 'react';
import { useSelector } from 'react-redux';
import { motion, useScroll, useSpring } from 'framer-motion';
import { Virtuoso } from 'react-virtuoso';
import { RootState } from '../store/store';
import { getSpreadPositions } from '../data/cards';
import RevealedCard from './RevealedCard';
import PaymentModal from './PaymentModal';
import usePayment from '../hooks/usePayment';

interface RevealedCardsProps {
  spreadType: string;
}

const RevealedCards: React.FC<RevealedCardsProps> = ({ spreadType }) => {
  const { revealedCards } = useSelector((state: RootState) => state.tarot);
  const positions = getSpreadPositions(spreadType);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { isProcessing, processPayment } = usePayment();
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    container: containerRef
  });

  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  const handlePaymentClick = () => {
    setIsModalOpen(true);
  };

  const handlePaymentProceed = async () => {
    await processPayment();
    setIsModalOpen(false);
  };

  const totalCardsForSpread = {
    'tirada-celta': 10,
    'tirada-estrella': 7,
    'tirada-amor': 8,
    'tirada-tiempo': 3,
    'si-o-no': 1
  }[spreadType] || 0;

  const showPaymentButton = revealedCards.length === totalCardsForSpread && totalCardsForSpread > 0;

  return (
    <>
      <motion.div 
        ref={containerRef}
        className="mt-12 max-w-4xl mx-auto px-4 pb-24 h-[calc(100vh-200px)] overflow-y-auto"
      >
        <Virtuoso
          style={{ height: '100%' }}
          totalCount={revealedCards.length}
          itemContent={index => (
            <motion.div
              initial={{ opacity: 0, x: 100, filter: 'blur(10px)' }}
              whileInView={{ 
                opacity: 1, 
                x: 0, 
                filter: 'blur(0px)',
                transition: { 
                  duration: 0.8,
                  delay: 0.1,
                  ease: [0.43, 0.13, 0.23, 0.96]
                }
              }}
              viewport={{ once: true, margin: "-100px" }}
              className="mb-6"
            >
              <RevealedCard
                card={revealedCards[index]}
                position={positions[index]}
                spreadType={spreadType}
                positionNumber={index + 1}
              />
            </motion.div>
          )}
        />

        {showPaymentButton && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handlePaymentClick}
            disabled={isProcessing}
            className="fixed bottom-8 right-8 z-50 bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-full shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isProcessing ? 'Procesando...' : 'Generar Lectura Completa con IA'}
          </motion.button>
        )}

        <motion.div
          className="fixed top-0 left-0 right-0 h-1 bg-purple-600 origin-left z-50"
          style={{ scaleX }}
        />
      </motion.div>

      <PaymentModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onProceed={handlePaymentProceed}
      />
    </>
  );
};

export default RevealedCards;