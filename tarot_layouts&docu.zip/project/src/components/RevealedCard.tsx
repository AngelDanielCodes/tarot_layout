import React from 'react';
import { motion } from 'framer-motion';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import Typewriter from 'typewriter-effect';
import { TarotCard } from '../types/cards';
import { getSpreadDescription } from '../data/cards';
import 'react-lazy-load-image-component/src/effects/opacity.css';

interface RevealedCardProps {
  card: TarotCard;
  position: string;
  spreadType: string;
  positionNumber: number;
}

const RevealedCard: React.FC<RevealedCardProps> = ({
  card,
  position,
  spreadType,
  positionNumber
}) => {
  const positionDescription = getSpreadDescription(spreadType, positionNumber);

  return (
    <motion.div
      className="flex gap-6 bg-black/30 backdrop-blur-sm rounded-lg p-6 text-white"
      layout
    >
      <motion.div 
        className="w-1/3 aspect-[2/3] relative rounded-lg overflow-hidden"
        layoutId={`card-${card.id}`}
      >
        <LazyLoadImage
          src={card.image}
          alt={card.name}
          effect="opacity"
          className="absolute inset-0 w-full h-full object-cover"
          width={300}
          height={450}
          placeholderSrc={card.image}
        />
      </motion.div>
      <div className="w-2/3">
        <motion.h3 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-xl font-semibold mb-2"
        >
          {position}
        </motion.h3>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-sm text-purple-300 mb-4"
        >
          {positionDescription}
        </motion.p>
        <motion.h4 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-2xl font-bold mb-4"
        >
          {card.name}
        </motion.h4>
        <div className="text-sm leading-relaxed">
          <Typewriter
            onInit={(typewriter) => {
              typewriter
                .changeDelay(30)
                .typeString(card.description)
                .start();
            }}
            options={{
              delay: 30,
              cursor: '',
              wrapperClassName: 'whitespace-pre-wrap',
              autoStart: true
            }}
          />
        </div>
      </div>
    </motion.div>
  );
};

export default RevealedCard;