import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { TarotCard } from '../types/cards';

interface TarotState {
  selectedCards: number[];
  revealedCards: TarotCard[];
  usedCardIds: number[];
  currentSpread: string;
  isRevealing: boolean;
  isComplete: boolean;
}

const initialState: TarotState = {
  selectedCards: [],
  revealedCards: [],
  usedCardIds: [],
  currentSpread: '',
  isRevealing: false,
  isComplete: false
};

export const tarotSlice = createSlice({
  name: 'tarot',
  initialState,
  reducers: {
    selectCard: (state, action: PayloadAction<number>) => {
      if (!state.selectedCards.includes(action.payload)) {
        state.selectedCards.push(action.payload);
      }
    },
    revealCard: (state, action: PayloadAction<TarotCard>) => {
      if (action.payload && !state.usedCardIds.includes(action.payload.id)) {
        state.revealedCards.push(action.payload);
        state.usedCardIds.push(action.payload.id);
      }
    },
    setSpread: (state, action: PayloadAction<string>) => {
      state.currentSpread = action.payload;
      state.selectedCards = [];
      state.revealedCards = [];
      state.usedCardIds = [];
      state.isRevealing = false;
      state.isComplete = false;
    },
    setRevealing: (state, action: PayloadAction<boolean>) => {
      state.isRevealing = action.payload;
    },
    setComplete: (state, action: PayloadAction<boolean>) => {
      state.isComplete = action.payload;
    },
    resetSpread: () => initialState
  }
});

export const { 
  selectCard, 
  revealCard, 
  setSpread, 
  resetSpread,
  setRevealing,
  setComplete 
} = tarotSlice.actions;

export default tarotSlice.reducer;