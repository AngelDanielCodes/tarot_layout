import { useState, useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { selectCard, revealCard, setSpread, setRevealing, setComplete } from '../store/tarotSlice';
import { RootState } from '../store/store';
import { getCards } from '../data/cards';
import { useTarotSound } from './useTarotSound';
import { useLocation } from 'react-router-dom';

const useCardReveal = (totalCards: number) => {
  const location = useLocation();
  const dispatch = useDispatch();
  const { playCardFlip, playCardSelect } = useTarotSound();
  const [isAnimating, setIsAnimating] = useState(false);
  
  const { selectedCards, usedCardIds, isRevealing, currentSpread } = useSelector(
    (state: RootState) => state.tarot
  );

  useEffect(() => {
    const spreadType = location.pathname.slice(1);
    if (spreadType && spreadType !== currentSpread) {
      dispatch(setSpread(spreadType));
    }
  }, [location, dispatch, currentSpread]);

  const getRandomCard = useCallback(() => {
    const spreadCards = getCards(currentSpread);
    const availableCards = spreadCards.filter(card => !usedCardIds.includes(card.id));
    if (availableCards.length === 0) return null;
    return availableCards[Math.floor(Math.random() * availableCards.length)];
  }, [usedCardIds, currentSpread]);

  const handleCardClick = useCallback(async (position: number) => {
    if (isRevealing || isAnimating) return;
    if (position !== selectedCards.length + 1) return;

    try {
      setIsAnimating(true);
      dispatch(setRevealing(true));
      
      await playCardSelect();
      dispatch(selectCard(position));

      const newCard = getRandomCard();
      if (!newCard) {
        console.error('No more available cards');
        return;
      }

      await new Promise(resolve => setTimeout(resolve, 300));
      await playCardFlip();

      dispatch(revealCard(newCard));

      if (selectedCards.length + 1 === totalCards) {
        dispatch(setComplete(true));
      }
    } catch (error) {
      console.error('Error in card reveal:', error);
    } finally {
      setIsAnimating(false);
      dispatch(setRevealing(false));
    }
  }, [
    selectedCards.length,
    usedCardIds,
    isRevealing,
    isAnimating,
    dispatch,
    playCardFlip,
    playCardSelect,
    totalCards,
    getRandomCard
  ]);

  const isCardSelectable = useCallback((position: number) => {
    return position === selectedCards.length + 1 && !isRevealing && !isAnimating;
  }, [selectedCards.length, isRevealing, isAnimating]);

  return {
    selectedCards,
    remainingCards: totalCards - selectedCards.length,
    handleCardClick,
    isCardSelectable,
    isRevealing: isRevealing || isAnimating
  };
};

export default useCardReveal;