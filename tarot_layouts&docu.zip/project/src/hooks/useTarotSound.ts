import { useEffect, useRef } from 'react';
import { Howl } from 'howler';

export const useTarotSound = () => {
  const flipSoundRef = useRef<Howl | null>(null);
  const selectSoundRef = useRef<Howl | null>(null);

  useEffect(() => {
    flipSoundRef.current = new Howl({
      src: ['/sounds/card-flip.wav'],
      volume: 0.5,
      preload: true,
      format: ['wav']
    });

    selectSoundRef.current = new Howl({
      src: ['/sounds/card-select.wav'],
      volume: 0.3,
      preload: true,
      format: ['wav']
    });

    return () => {
      flipSoundRef.current?.unload();
      selectSoundRef.current?.unload();
    };
  }, []);

  const playCardFlip = async () => {
    try {
      if (flipSoundRef.current) {
        flipSoundRef.current.play();
      }
    } catch (error) {
      console.error('Error playing flip sound:', error);
    }
  };

  const playCardSelect = async () => {
    try {
      if (selectSoundRef.current) {
        selectSoundRef.current.play();
      }
    } catch (error) {
      console.error('Error playing select sound:', error);
    }
  };

  return {
    playCardFlip,
    playCardSelect
  };
};