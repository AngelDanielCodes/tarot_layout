import React from 'react';
import TarotCard from '../components/TarotCard';
import TarotSpreadLayout from '../components/TarotSpreadLayout';
import RevealedCards from '../components/RevealedCards';
import useCardReveal from '../hooks/useCardReveal';

const CelticCross = () => {
  const { selectedCards, remainingCards, handleCardClick, isCardSelectable } = useCardReveal(10);

  return (
    <TarotSpreadLayout
      title="Tirada Celta"
      remainingCards={remainingCards}
      backgroundImage="https://images.unsplash.com/photo-1534447677768-be436bb09401"
    >
      <div className="relative max-w-6xl mx-auto h-[800px] flex items-center justify-center p-8">
        <div className="relative w-full h-full max-w-4xl mx-auto">
          {/* Centro - Carta 1 */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
            <TarotCard
              position={1}
              isRevealed={selectedCards.includes(1)}
              isSelectable={isCardSelectable(1)}
              onClick={() => handleCardClick(1)}
              spreadType="tirada-celta"
            />
          </div>

          {/* Carta 2 - Cruzada */}
          <div className="absolute top-1/2 left-[calc(50%+80px)] -translate-x-1/2 -translate-y-1/2 rotate-90 z-20">
            <TarotCard
              position={2}
              isRevealed={selectedCards.includes(2)}
              isSelectable={isCardSelectable(2)}
              onClick={() => handleCardClick(2)}
              spreadType="tirada-celta"
            />
          </div>

          {/* Cruz vertical - Cartas 3 y 4 */}
          <div className="absolute top-[15%] left-1/2 -translate-x-1/2">
            <TarotCard
              position={3}
              isRevealed={selectedCards.includes(3)}
              isSelectable={isCardSelectable(3)}
              onClick={() => handleCardClick(3)}
              spreadType="tirada-celta"
            />
          </div>

          <div className="absolute top-[85%] left-1/2 -translate-x-1/2">
            <TarotCard
              position={4}
              isRevealed={selectedCards.includes(4)}
              isSelectable={isCardSelectable(4)}
              onClick={() => handleCardClick(4)}
              spreadType="tirada-celta"
            />
          </div>

          {/* Cruz horizontal - Cartas 5 y 6 */}
          <div className="absolute top-1/2 left-[15%] -translate-y-1/2">
            <TarotCard
              position={5}
              isRevealed={selectedCards.includes(5)}
              isSelectable={isCardSelectable(5)}
              onClick={() => handleCardClick(5)}
              spreadType="tirada-celta"
            />
          </div>

          <div className="absolute top-1/2 right-[15%] -translate-y-1/2">
            <TarotCard
              position={6}
              isRevealed={selectedCards.includes(6)}
              isSelectable={isCardSelectable(6)}
              onClick={() => handleCardClick(6)}
              spreadType="tirada-celta"
            />
          </div>

          {/* Columna derecha - Cartas 7-10 */}
          <div className="absolute right-[-150px] top-0 h-full flex flex-col justify-between py-8">
            <TarotCard
              position={7}
              isRevealed={selectedCards.includes(7)}
              isSelectable={isCardSelectable(7)}
              onClick={() => handleCardClick(7)}
              spreadType="tirada-celta"
            />
            <TarotCard
              position={8}
              isRevealed={selectedCards.includes(8)}
              isSelectable={isCardSelectable(8)}
              onClick={() => handleCardClick(8)}
              spreadType="tirada-celta"
            />
            <TarotCard
              position={9}
              isRevealed={selectedCards.includes(9)}
              isSelectable={isCardSelectable(9)}
              onClick={() => handleCardClick(9)}
              spreadType="tirada-celta"
            />
            <TarotCard
              position={10}
              isRevealed={selectedCards.includes(10)}
              isSelectable={isCardSelectable(10)}
              onClick={() => handleCardClick(10)}
              spreadType="tirada-celta"
            />
          </div>
        </div>
      </div>

      <RevealedCards spreadType="tirada-celta" />
    </TarotSpreadLayout>
  );
};

export default CelticCross;