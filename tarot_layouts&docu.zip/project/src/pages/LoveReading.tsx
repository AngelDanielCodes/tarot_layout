import React from 'react';
import TarotCard from '../components/TarotCard';
import TarotSpreadLayout from '../components/TarotSpreadLayout';
import RevealedCards from '../components/RevealedCards';
import useCardReveal from '../hooks/useCardReveal';

const LoveReading = () => {
  const { selectedCards, remainingCards, handleCardClick, isCardSelectable } = useCardReveal(8);

  return (
    <TarotSpreadLayout
      title="Tirada del Amor"
      remainingCards={remainingCards}
      backgroundImage="https://images.unsplash.com/photo-1518531933037-91b2f5f229cc"
    >
      <div className="relative max-w-6xl mx-auto h-[800px] flex items-center justify-center p-8">
        <div className="relative w-full h-full max-w-4xl mx-auto">
          {/* Carta 1 - Consultante */}
          <div className="absolute top-[10%] left-1/2 -translate-x-1/2">
            <TarotCard
              position={1}
              isRevealed={selectedCards.includes(1)}
              isSelectable={isCardSelectable(1)}
              onClick={() => handleCardClick(1)}
              spreadType="tirada-amor"
            />
          </div>

          {/* Curvas superiores del corazón */}
          <div className="absolute top-[25%] left-[25%] -rotate-[45deg]">
            <TarotCard
              position={2}
              isRevealed={selectedCards.includes(2)}
              isSelectable={isCardSelectable(2)}
              onClick={() => handleCardClick(2)}
              spreadType="tirada-amor"
            />
          </div>

          <div className="absolute top-[25%] right-[25%] rotate-[45deg]">
            <TarotCard
              position={8}
              isRevealed={selectedCards.includes(8)}
              isSelectable={isCardSelectable(8)}
              onClick={() => handleCardClick(8)}
              spreadType="tirada-amor"
            />
          </div>

          {/* Parte media del corazón */}
          <div className="absolute top-[45%] left-[15%] -rotate-[15deg]">
            <TarotCard
              position={3}
              isRevealed={selectedCards.includes(3)}
              isSelectable={isCardSelectable(3)}
              onClick={() => handleCardClick(3)}
              spreadType="tirada-amor"
            />
          </div>

          <div className="absolute top-[45%] right-[15%] rotate-[15deg]">
            <TarotCard
              position={7}
              isRevealed={selectedCards.includes(7)}
              isSelectable={isCardSelectable(7)}
              onClick={() => handleCardClick(7)}
              spreadType="tirada-amor"
            />
          </div>

          {/* Parte inferior del corazón */}
          <div className="absolute top-[65%] left-[25%] rotate-[45deg]">
            <TarotCard
              position={4}
              isRevealed={selectedCards.includes(4)}
              isSelectable={isCardSelectable(4)}
              onClick={() => handleCardClick(4)}
              spreadType="tirada-amor"
            />
          </div>

          <div className="absolute top-[65%] right-[25%] -rotate-[45deg]">
            <TarotCard
              position={6}
              isRevealed={selectedCards.includes(6)}
              isSelectable={isCardSelectable(6)}
              onClick={() => handleCardClick(6)}
              spreadType="tirada-amor"
            />
          </div>

          {/* Punta del corazón */}
          <div className="absolute top-[85%] left-1/2 -translate-x-1/2">
            <TarotCard
              position={5}
              isRevealed={selectedCards.includes(5)}
              isSelectable={isCardSelectable(5)}
              onClick={() => handleCardClick(5)}
              spreadType="tirada-amor"
            />
          </div>
        </div>
      </div>

      <RevealedCards spreadType="tirada-amor" />
    </TarotSpreadLayout>
  );
};

export default LoveReading;