import React from 'react';
import TarotCard from '../components/TarotCard';
import TarotSpreadLayout from '../components/TarotSpreadLayout';
import RevealedCards from '../components/RevealedCards';
import useCardReveal from '../hooks/useCardReveal';

const StarSpread = () => {
  const { selectedCards, remainingCards, handleCardClick, isCardSelectable } = useCardReveal(7);

  return (
    <TarotSpreadLayout
      title="Tirada Estrella"
      remainingCards={remainingCards}
      backgroundImage="https://images.unsplash.com/photo-1519810755548-39cd217da494"
    >
      <div className="relative max-w-6xl mx-auto h-[800px] flex items-center justify-center p-8">
        <div className="relative w-full h-full max-w-4xl mx-auto">
          {/* Carta 1 - Superior */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2">
            <TarotCard
              position={1}
              isRevealed={selectedCards.includes(1)}
              isSelectable={isCardSelectable(1)}
              onClick={() => handleCardClick(1)}
              spreadType="tirada-estrella"
            />
          </div>

          {/* Carta 2 - Izquierda Superior */}
          <div className="absolute top-[20%] left-[10%]">
            <TarotCard
              position={2}
              isRevealed={selectedCards.includes(2)}
              isSelectable={isCardSelectable(2)}
              onClick={() => handleCardClick(2)}
              spreadType="tirada-estrella"
            />
          </div>

          {/* Carta 3 - Derecha Superior */}
          <div className="absolute top-[20%] right-[10%]">
            <TarotCard
              position={3}
              isRevealed={selectedCards.includes(3)}
              isSelectable={isCardSelectable(3)}
              onClick={() => handleCardClick(3)}
              spreadType="tirada-estrella"
            />
          </div>

          {/* Carta 4 - Inferior */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2">
            <TarotCard
              position={4}
              isRevealed={selectedCards.includes(4)}
              isSelectable={isCardSelectable(4)}
              onClick={() => handleCardClick(4)}
              spreadType="tirada-estrella"
            />
          </div>

          {/* Carta 5 - Izquierda Inferior */}
          <div className="absolute bottom-[20%] left-[10%]">
            <TarotCard
              position={5}
              isRevealed={selectedCards.includes(5)}
              isSelectable={isCardSelectable(5)}
              onClick={() => handleCardClick(5)}
              spreadType="tirada-estrella"
            />
          </div>

          {/* Carta 6 - Derecha Inferior */}
          <div className="absolute bottom-[20%] right-[10%]">
            <TarotCard
              position={6}
              isRevealed={selectedCards.includes(6)}
              isSelectable={isCardSelectable(6)}
              onClick={() => handleCardClick(6)}
              spreadType="tirada-estrella"
            />
          </div>

          {/* Carta 7 - Centro */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <TarotCard
              position={7}
              isRevealed={selectedCards.includes(7)}
              isSelectable={isCardSelectable(7)}
              onClick={() => handleCardClick(7)}
              spreadType="tirada-estrella"
            />
          </div>
        </div>
      </div>

      <RevealedCards spreadType="tirada-estrella" />
    </TarotSpreadLayout>
  );
};

export default StarSpread;