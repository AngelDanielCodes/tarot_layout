/// <reference types="vite/client" />

// Declarar módulos para archivos de audio
declare module '*.mp3' {
  const src: string;
  export default src;
}

declare module '*.wav' {
  const src: string;
  export default src;
}